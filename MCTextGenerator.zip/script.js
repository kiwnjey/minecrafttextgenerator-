function generateMinecraftText() {
    var userInput = document.getElementById('userInput').value;
    var minecraftStyledText = userInput.split('').join(' '); // Simple text styling logic
    document.getElementById('minecraftText').innerText = minecraftStyledText;
}
